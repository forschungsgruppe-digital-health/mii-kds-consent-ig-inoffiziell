# MII Consent: Answer CodeSystem - MII Implementation Guide Consent v2026.0.0

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII Consent: Answer CodeSystem**

## CodeSystem: MII Consent: Answer CodeSystem 

| | |
| :--- | :--- |
| *Offizielle URL*:urn:oid:2.16.840.1.113883.3.1937.777.24.5.2 | *Version*:2026.0.0 |
| Active Stand: 2021-03-23 | *Maschinenlesbarer Name*:MII_CS_Consent_Answer |

 
This CodeSystem contains the possible answers to the questions of the MII Consent. 

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* [MII_VS_Consent_Answer](ValueSet-2.16.840.1.113883.3.1937.777.24.11.30--20210323234509.md)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "2.16.840.1.113883.3.1937.777.24.5.2--20210423105554",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem"]
  },
  "url" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.2",
  "version" : "2026.0.0",
  "name" : "MII_CS_Consent_Answer",
  "title" : "MII Consent: Answer CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2021-03-23",
  "publisher" : "Medical Informatics Initiative (MII)",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik-Initiative (MII)"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medical Informatics Initiative (MII)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "This CodeSystem contains the possible answers to the questions of the MII Consent.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "valueSet" : "https://www.medizininformatik-initiative.de/fhir/modul-consent/ValueSet/mii-vs-consent-answer",
  "hierarchyMeaning" : "part-of",
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "2.16.840.1.113883.3.1937.777.24.5.2.3",
    "display" : "unbekannt",
    "designation" : [{
      "language" : "de-DE",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "unbekannt"
    },
    {
      "language" : "en-US",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "unknown"
    }]
  },
  {
    "code" : "2.16.840.1.113883.3.1937.777.24.5.2.2",
    "display" : "nicht gültig",
    "designation" : [{
      "language" : "de-DE",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "nicht gültig"
    },
    {
      "language" : "en-US",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "not valid"
    }]
  },
  {
    "code" : "2.16.840.1.113883.3.1937.777.24.5.2.1",
    "display" : "gültig",
    "designation" : [{
      "language" : "de-DE",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "gültig"
    },
    {
      "language" : "en-US",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "valid"
    }]
  }]
}

```
