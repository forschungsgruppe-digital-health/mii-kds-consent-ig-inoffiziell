# Profile - MI-I - Consent - Provenance - MII Implementation Guide Consent v2026.0.0

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Profile - MI-I - Consent - Provenance**

## Ressourcenprofil: Profile - MI-I - Consent - Provenance 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-provenance | *Version*:2026.0.0 |
| Draft Stand: 2023-05-09 | *Maschinenlesbarer Name*:MII_PR_Consent_Provenance |

 
Dieses Profil beschreibt Herkunftsinformationen zu Einwilligungen in der Medizininformatik-Initiative. 

Basierend auf den [Empfehlungen](https://ig.fhir.de/einwilligungsmanagement/stable/Provenance.html) der AG Einwilligungsmanagement beschreibt das Profil **MIIConsentProvenance** die Herkunftsinformationen eines Einwilligungsdokuments.

Die Provenance-Ressource verknüpft die Einwilligungsinhalte — unter anderem die Unterschriften — mit den beteiligten Personen und mit einem eventuell vorhandenen Dokumenten-Scan; siehe [UML-Diagramme](uml-diagrams.md).

**Usages:**

* Examples for this Profile: [Provenance/55219d12-6245-4de4-8b50-ddf6f16a789b](Provenance-55219d12-6245-4de4-8b50-ddf6f16a789b.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.consent|current/StructureDefinition/StructureDefinition-f675b1e8-9f3f-44e8-bb59-9681f78eb464.json)

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Schlüsselelemente-Tabelle](#tabs-key) 
*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [ConsentManagementProvenance](https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2-snapshots&canonical=http://fhir.de/ConsentManagement/StructureDefinition/Provenance) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [ConsentManagementProvenance](https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2-snapshots&canonical=http://fhir.de/ConsentManagement/StructureDefinition/Provenance) 

** Summary **

**Structures**

This structure refers to these other structures:

* [Profile - MI-I - Consent - DocumentReference (https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-documentreference)](StructureDefinition-56375452-bfa1-4111-af7c-5b5ba9a1857c.md)

 **Schlüsselelemente-Ansicht** 

#### Terminology Bindings

#### Constraints

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [ConsentManagementProvenance](https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2-snapshots&canonical=http://fhir.de/ConsentManagement/StructureDefinition/Provenance) 

#### Terminology Bindings (Differential)

 **Snapshot-AnsichtView** 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [ConsentManagementProvenance](https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2-snapshots&canonical=http://fhir.de/ConsentManagement/StructureDefinition/Provenance) 

** Summary **

**Structures**

This structure refers to these other structures:

* [Profile - MI-I - Consent - DocumentReference (https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-documentreference)](StructureDefinition-56375452-bfa1-4111-af7c-5b5ba9a1857c.md)

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-f675b1e8-9f3f-44e8-bb59-9681f78eb464.csv), [Excel](../StructureDefinition-f675b1e8-9f3f-44e8-bb59-9681f78eb464.xlsx), [Schematron](../StructureDefinition-f675b1e8-9f3f-44e8-bb59-9681f78eb464.sch) 

### Notizen:

**Nachfolgend werden nur die Unterschiede zum [Basis-Profil](https://ig.fhir.de/einwilligungsmanagement/stable/Provenance.html) erläutert.**

| | |
| :--- | :--- |
| `Provenance.entity.what` | Soll ein Dokumenten-Scan angehängt werden, muss die referenzierte Ressource vom Profiltyp[DocumentReference](StructureDefinition-56375452-bfa1-4111-af7c-5b5ba9a1857c.md)sein, Must-support |
| `Provenance.entity.signature.type` | Soll eine base64-codierte Unterschrift angehängt werden, muss die Art der Unterschrift gemäß[MII_VS_Consent_SignatureTypes](ValueSet-88464c5b-5338-4c2b-9c07-b42fef2ada64.md)erfolgen, Must-support |

### Beispiel

* [Beispiel (vollständig)](Provenance-55219d12-6245-4de4-8b50-ddf6f16a789b.md)

> **TODO:REVIEW (Gate B).** Auf der gerenderten Quellseite schlug die Einbettung genau dieses Beispiels fehl („File not found“). Das Beispiel existiert im Modul und wird von diesem Leitfaden als eigene Artefaktseite gerendert — die Migration behebt damit einen Renderfehler der Quelle. Bitte bestätigen, dass es dasselbe Beispiel ist, das die Quelle einbetten wollte.



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "f675b1e8-9f3f-44e8-bb59-9681f78eb464",
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-provenance",
  "version" : "2026.0.0",
  "name" : "MII_PR_Consent_Provenance",
  "title" : "Profile - MI-I - Consent - Provenance",
  "status" : "draft",
  "date" : "2023-05-09",
  "publisher" : "Medical Informatics Initiative (MII)",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik-Initiative (MII)"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medical Informatics Initiative (MII)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    }]
  }],
  "description" : "Dieses Profil beschreibt Herkunftsinformationen zu Einwilligungen in der Medizininformatik-Initiative.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "w3c.prov",
    "uri" : "http://www.w3.org/ns/prov",
    "name" : "W3C PROV"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "fhirauditevent",
    "uri" : "http://hl7.org/fhir/auditevent",
    "name" : "FHIR AuditEvent Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Provenance",
  "baseDefinition" : "http://fhir.de/ConsentManagement/StructureDefinition/Provenance",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Provenance",
      "path" : "Provenance"
    },
    {
      "id" : "Provenance.entity.what",
      "path" : "Provenance.entity.what",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/modul-consent/StructureDefinition/mii-pr-consent-documentreference"]
      }]
    },
    {
      "id" : "Provenance.signature.type",
      "path" : "Provenance.signature.type",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/modul-consent/ValueSet/mii-vs-consent-signaturetypes"
      }
    }]
  }
}

```
