# Changelog - MII Implementation Guide Consent v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* **Changelog**

## Changelog

 This page includes translations from the original source language in which the guide was authored. Information on these translations and instructions on how to provide feedback on the translations can be found [here](translationinfo.html). 

### Change history

This page records the changes between the published versions of the **Consent** module, most recent version first. It follows [Keep a Changelog](https://keepachangelog.com/de/1.1.0/) and the KDS CalVer scheme described on the [Versioning](version-history.md) page.

Each version gets its own section with the release date and the changes grouped by category:

* **Added** — new profiles, extensions, ValueSets, search parameters, pages.
* **Changed** — changed constraints, bindings, notes, or documentation.
* **Deprecated** — artifacts that still exist but should no longer be used.
* **Removed** — withdrawn artifacts.
* **Fixed** — corrections of errors.
* **Security** — changes affecting security or data protection.

Categories without content are omitted. If a change goes back to an issue or a pull request, it is linked.

##### Breaking changes MUST be reported and explained

A version section containing a breaking change is only complete once it explicitly answers, in this changelog:

* **What exactly changed** between the two versions — the artifact, the element, the old and the new constraint (not just "profile X was revised").
* **What this means for existing data:** Does data that conformed to the previous version still validate against the new version? If not: which resources and elements are affected, and how does the error show up?
* **What implementers should do:** the authors' recommendation for migrating existing data to the new version — transformation steps, default values, recoding guidance — or the explicit statement that no migration path is provided, and why.

**What counts as a breaking change** — treat a change as a breaking change if it does any of the following, even if it seems small: tightens a cardinality (`0..*` → `1..1`), raises a binding strength (example → required), removes codes from a required ValueSet, removes or renames an element or a slice, narrows a type, adds an invariant or a must-support obligation, or changes a canonical URL. When in doubt: report it as a breaking change.

**Breaking for whom:** name both perspectives — *stored data* (instances that are valid against the old version) and *implementations* (clients and servers built against it; a removed search parameter breaks implementations while every stored instance stays valid).

**The version number warns nobody.** The KDS calendar versioning scheme (`JJJJ.n.n`) carries no major signal like SemVer — this changelog section is the *only* warning readers get.

**Link the technical delta.** From the second formal publication onward, enable the IG Publisher's version comparison (`version-comparison` in `sushi-config.yaml` — see the [Versioning](version-history.md) page for the setup and its prerequisites); it publishes a machine-generated comparison at `comparison-v<Vorversion>/index.html`. Link it from the version section so that the explanation and the technical diff stand side by side.

Mark such entries clearly (for example with the prefix **BREAKING:**) so they cannot be overlooked when skimming the section.

-------

#### Version 2027.0.0-ballot.rc1

Date 31.08.2026

* **Changed** — migration of the guide onto the [MII KDS module template](https://github.com/medizininformatik-initiative/mii-kds-module-template) v0.13.2 (IG Publisher toolchain, DE-first language model, template page structure); **content-identical to release 2026.0.0** (profiles, terminology and examples unchanged; evidence: `migration-log/` on this branch). All artefact versions harmonized to the package version 2027.0.0-ballot.rc1 (previously divergent per artefact, e.g. 1.0.9/1.6.0/1.1.0).

#### Version 2026.0.0

Date 18.12.2025

* ValueSet **MII_VS_Consent_SignatureTypes** extended by the code **1.2.840.10065.1.12.1.5** "Verification Signature"
* CodeSystem **MII Consent: Policy CodeSystem** - supplemented with a period of validity per policy (property **period-of-validity** with an ISO 8601:2004 date string or 'einmalig') - Policy **2.16.840.1.113883.3.1937.777.24.5.3.46** "MDAT retrospektiv wissenschaftlich nutzen" is now marked as deprecated and should no longer be used - Policy **2.16.840.1.113883.3.1937.777.24.5.3.47** "MDAT retrospektiv zusammenfuehren Dritte" is now marked as deprecated and should no longer be used - Policy **2.16.840.1.113883.3.1937.777.24.5.3.16** "KKDAT 5J prospektiv speichern verarbeiten" is now marked as deprecated and should no longer be used - Policy **2.16.840.1.113883.3.1937.777.24.5.3.17** "KKDAT 5J prospektiv wissenschaftlich nutzen" is now marked as deprecated and should no longer be used - Markdown representation in table form created for displaying the CodeSystem under 'Terminologie' in the IG
* CodeSystem **mii-cs-consent-version-modules** created for the BC versions and additional modules - addition of OIDs for refusals (BC v1.6d and v1.7.2)
* **Consent.provision.period.end** and **Consent.provision.provision.period.end** are now cardinality 0..1, i.e. no longer mandatory
* Examples revised and supplemented
* IG: editorial revision and improved explanations - new page **Empfehlungen zur praktischen Anwendung** added (ResultType) - handling of withdrawals for consents of minors (period of validity or expiry of the consent) - notes on use in the Modellvorhaben Genomsequenzierung (§64e) - explanation of new search parameters added

Full Changelog: [https://github.com/medizininformatik-initiative/kerndatensatzmodul-consent/compare/2025.0.3…2026.0.0](https://github.com/medizininformatik-initiative/kerndatensatzmodul-consent/compare/2025.0.3...2026.0.0)

#### Version 2025.0.4

Date 16.06.2025

* Terminologies: - Policy CodeSystem resource display adjusted (abbreviations -> descriptive names)
* Bugfix: - pagelink error fixed

#### Version 2025.0.3

Date 12.06.2025

* IG/Consent: - support for the additional module Fachnetzwerk Infektion - SNID (Z4) added - support for the additional module Deutsche Zentrum für Psychische Gesundheit - DZPG (Z5) added - Consent: list of the available MII Consents for use in Consent.policy.uri updated - Terminologies: Policy CodeSystem extended by SNID and DZPG policies

Full Changelog: [https://github.com/medizininformatik-initiative/kerndatensatzmodul-consent/compare/2025.0.0…2025.0.3](https://github.com/medizininformatik-initiative/kerndatensatzmodul-consent/compare/2025.0.0...2025.0.3)

#### Version 2025.0.2

Date 11.06.2025

* IG/Consent: - support for the additional module Fachnetzwerk Infektion - SNID (Z4) added - Consent: list of the available MII Consents for use in Consent.policy.uri updated - Terminologies: Policy CodeSystem extended by SNID policies

#### Version 2025.0.1

Date 21.01.2025

* IG/Consent: - list of the available MII Consents for use in Consent.policy.uri updated: - additional module ACRIBiS (Z2) - additional module Patientenbefragung (Z3)

#### Version 2025.0.0

Date 17.12.2024

* Consent resource - Consent.category -> max value="*" - Consent.provision.type ->fixedCode deny removed - Consent.provision.provision.type ->fixedCode permit removed￼ - IG/Consent adjusted accordingly
* IG/Consent - list of the available MII Consents for use in Consent.policy.uri updated (withdrawals and minors)
* Policy CodeSystem: acribis and PROM policies added
* IG/Terminology: - level information corrected - formatting of the note text corrected - note 1 (FHIR+policies) corrected

Full Changelog: [https://github.com/medizininformatik-initiative/kerndatensatzmodul-consent/compare/1.0.7…2025.0.0](https://github.com/medizininformatik-initiative/kerndatensatzmodul-consent/compare/1.0.7...2025.0.0)

