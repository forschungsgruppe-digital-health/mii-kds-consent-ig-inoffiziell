# Extensions - MII Implementation Guide Consent v2026.0.0

* [**Table of Contents**](toc.md)
* **Extensions**

## Extensions

> **Optionale Seite (0..1).** Das KDS-Modulmenü führt diese Seite als **optional**. Entscheiden Sie für Ihr Modul: Seite **behalten** — Inhalte ausfüllen und dieses Banner samt `OPTIONAL-PAGE`-Marker-Kommentar löschen (in dieser Datei UND in der englischen Quellseite) — oder Seite **entfernen**, nach der Schritt-für-Schritt-Anleitung in [`docs/optional-pages.md`](https://github.com/forschungsgruppe-digital-health/mii-kds-consent-ig-inoffiziell/blob/main/docs/optional-pages.md) dieses Repositories. Ein Release darf dieses Banner nicht enthalten (Konventions-Check M9).

### Extensions

Diese Seite listet die FHIR-Extensions, die das Modul **Consent** definiert (Namenskonvention `MII_EX_<Modul>_<Name>`). Extensions transportieren Informationen, die die Basis-Ressourcen und Profile nicht ausdrücken können; die Profile, die sie verwenden, stehen auf der Seite [Profile](profiles.md).

> [TODO: Listen und beschreiben Sie die Extensions Ihres Moduls — oder entfernen Sie diese Seite, wenn Ihr Modul keine definiert.]

