# de.medizininformatikinitiative.kerndatensatz.consent#2026.0.0: MII Implementation Guide Consent(en)

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Questionnaires](frageboegen.md)
* [Value Sets](value-sets.md)
* [Code Systems](code-systems.md)
* [Versioning](version-history.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Search Parameters](search-parameters.md)
* [Translation Information](translationinfo.md)
* [Changelog](changes.md)
* [Logical Models](logical-models.md)
* [Guidance](guidance.md)
* [Downloads](downloads.md)
* [Security and Privacy](security-and-privacy.md)
* [Capability Statements](capability-statements.md)
* [UML Diagrams](uml-diagrams.md)

## Resources

### CodeSystems

* [MII Consent: Answer CodeSystem](CodeSystem-2.16.840.1.113883.3.1937.777.24.5.2--20210423105554.md)
* [MII Consent: Policy CodeSystem](CodeSystem-2.16.840.1.113883.3.1937.777.24.5.3--20251211153003.md)
* [MII Consent Version and Modules CodeSystem](CodeSystem-mii-cs-consent-version-modules.md)

### ValueSets

* [MII Consent: Answer ValueSet](ValueSet-2.16.840.1.113883.3.1937.777.24.11.30--20210323234509.md)
* [MII Consent: Policy ValueSet](ValueSet-2.16.840.1.113883.3.1937.777.24.11.36--20230331232804.md)
* [MII Consent: Signature Types](ValueSet-88464c5b-5338-4c2b-9c07-b42fef2ada64.md)

### Resource Profiles

* [Profile - MI-I - Consent - DocumentReference](StructureDefinition-56375452-bfa1-4111-af7c-5b5ba9a1857c.md)
* [Profile - MI-I - Consent - Einwilligung](StructureDefinition-e0e166b4-0f77-478d-9062-de0034d98ce0.md)
* [Profile - MI-I - Consent - Provenance](StructureDefinition-f675b1e8-9f3f-44e8-bb59-9681f78eb464.md)

### CapabilityStatements

* [MII KDS Modul Consent — CapabilityStatement (Migrationsvorschlag)](CapabilityStatement-mii-cap-consent-server.md)

### ImplementationGuides

* [MII Implementation Guide Consent](ImplementationGuide-mii-ig-consent.md)

### Parameters

* [mii-param-consent-manifest](Parameters-mii-param-consent-manifest.md)

### SearchParameters

* [MII_SP_Consent_PolicyUri](SearchParameter-MII-SP-Consent-PolicyUri.md)
* [MII_SP_Consent_ProvisionCode](SearchParameter-MII-SP-Consent-ProvisionCode.md)
* [MII_SP_Consent_ProvisionCodePeriod](SearchParameter-MII-SP-Consent-ProvisionCodePeriod.md)
* [MII_SP_Consent_ProvisionCodeType](SearchParameter-MII-SP-Consent-ProvisionCodeType.md)
* [MII_SP_Consent_ProvisionPeriod](SearchParameter-MII-SP-Consent-ProvisionPeriod.md)
* [MII_SP_Consent_ProvisionType](SearchParameter-MII-SP-Consent-ProvisionType.md)

### Examples

* [34150a23-b1c8-404f-874f-e042a30435d2 (Consent)](Consent-34150a23-b1c8-404f-874f-e042a30435d2.md)
* [5143266b-8d60-4b28-8ee9-635140ffa5bb (Consent)](Consent-5143266b-8d60-4b28-8ee9-635140ffa5bb.md)
* [89f494a3-cd75-44f5-a78a-581dfdd47a94 (Consent)](Consent-89f494a3-cd75-44f5-a78a-581dfdd47a94.md)
* [Example-MII-Consent-ResultType-document (Consent)](Consent-Example-MII-Consent-ResultType-document.md)
* [8a3d1799-2463-405e-b49c-6a16c8692b01 (DocumentReference)](DocumentReference-8a3d1799-2463-405e-b49c-6a16c8692b01.md)
* [55219d12-6245-4de4-8b50-ddf6f16a789b (Provenance)](Provenance-55219d12-6245-4de4-8b50-ddf6f16a789b.md)
